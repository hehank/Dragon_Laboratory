d1 = {1: 'apple', 2: 'ball'}
d2 = {
    "name": "joe",
    1: [2, 4, 6]
    }
d3 = dict([(1, "tom"), (2, "mary"), (3, "john")])
print(d1)
print(d2)
print("d3 = " + str(d3))

