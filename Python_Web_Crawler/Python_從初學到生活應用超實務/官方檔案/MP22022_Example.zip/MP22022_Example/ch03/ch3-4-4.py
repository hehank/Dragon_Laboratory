d1 = {1:1, 3:9, 5:24, 7:47, 9:83}
print("d1 = " + str(d1))
s = len(d1)
d2 = dict([(1,"tom"), (2,"mary"), (3, "joe")])
print("d2 = " + str(d2))
d3 = sorted(d1)
print("d3 = sorted(d1) = " + str(d3))
 