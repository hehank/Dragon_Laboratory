lst1 = [1, 2, 3, 4, 5]
lst2 = [1, 'Python', 5.5]
lst3 = list(["tom", "mary", "joe"])
lst4 = list("python")
lst5 = [1, ["tom", "mary", "joe"], [3, 4, 5]]
print(lst1)
print(lst2, lst3, lst4)
print("lst5:" + str(lst5))

