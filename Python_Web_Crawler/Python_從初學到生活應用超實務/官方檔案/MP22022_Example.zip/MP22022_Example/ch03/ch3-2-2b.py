lst1 = [1, 2, 3, 4, 5, 6]
for e in lst1:
    print(e, end=" ")

