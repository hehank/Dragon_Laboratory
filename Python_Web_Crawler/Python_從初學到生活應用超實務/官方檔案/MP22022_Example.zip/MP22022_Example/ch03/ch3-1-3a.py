str1 = 'Hello World!'
print("str1 = " + str1)
s = len(str1)
print("len(str1) = " + str(s))
s = max(str1)
print("max(str1) = " + s)
s = min(str1)
print("min(str1) = " + s)