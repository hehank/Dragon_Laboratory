m, r, n = 100, 1, 1
while r <= m:
    r = r * n
    n = n + 1
print("大於100的階層n!=", n-1)
