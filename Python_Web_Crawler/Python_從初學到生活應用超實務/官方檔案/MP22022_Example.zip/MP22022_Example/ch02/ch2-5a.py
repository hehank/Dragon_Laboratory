r = n = 1
while n <= 5:
    r = r * n
    n = n + 1
else:
    print("while迴圈結束!")
    print("5!=", r)

      

 
