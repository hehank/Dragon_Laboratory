a, b = 3, 4
print("小於:( 3 < 4 )=", a < b)
print("大於:( 3 > 4 )=", a > b)
print("小於等於:( 3 <= 4 )=", a <= b)
print("大於等於:( 3 >= 4 )=", a >= b)
print("等於:( 3 == 4 )=", a == b)
print("不等於:( 3 != 4 )=", a != b)
print("a =", str(a), " b =", str(b))
print("( 2 <= a <= 5 )=", 2 <= a <= 5)
print("( 12 >= b >= 5 )=", 12 >= b >= 5)

