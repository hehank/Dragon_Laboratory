m = int(input("請輸入最大值 : "))
s = 0
for i in range(1, m + 1):
    s = s + i
print("總和 = ", s)
