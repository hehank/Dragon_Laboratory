for b in range(1, 5):
    print("b = ", b)

