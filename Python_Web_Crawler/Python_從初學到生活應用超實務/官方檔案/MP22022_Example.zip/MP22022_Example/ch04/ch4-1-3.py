def convert_to_f(c):
    f = (9.0 * c) / 5.0 + 32.0
    return f

c = 100.00
f = convert_to_f(c)
print("攝氏:", c, " = 華氏:", f)


