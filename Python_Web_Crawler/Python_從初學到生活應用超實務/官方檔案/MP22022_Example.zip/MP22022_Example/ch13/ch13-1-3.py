import docx

doc = docx.Document()
doc.save("word文件.docx")
 


