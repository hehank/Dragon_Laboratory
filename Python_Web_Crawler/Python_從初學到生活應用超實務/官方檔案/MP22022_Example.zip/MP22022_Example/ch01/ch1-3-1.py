score1 = 35
score2 = 10
score3 = 10
score2 = 27
score3 = score2
print("第一節 = ", score1)
print("第二節 = ", score2)
print("第三節 = ", score3)


