f = 1.0
g = 55.22
print(type(f))
print(type(g))






