str1 = "學習Python程式設計"
str2 = 'Hello World!'
print(type(str1))
print(type(str2))
ch1 = "A"
ch2 = 'b'
print(type(ch1))
print(type(ch2))
str3 = """學會Python程式"""
str4 = '''Welcome to the world
of Python'''
print(str3)
print(str4)
str5 = "It's my life."
print(str5)






