x, y = 10, 20
s = "Y= {} X= {}".format(x, y)
print(s)

