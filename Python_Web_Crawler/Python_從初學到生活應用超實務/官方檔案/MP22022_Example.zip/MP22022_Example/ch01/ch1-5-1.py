str1 = input("請輸入字串: ")
print("字串 = " + str1)
var1 = int(input("請輸入整數: "))
print("整數值 = " + str(var1))
var2 = float(input("請輸入浮點數: "))
print("浮點數值 = " + str(var2))
print("整數值 =" , var1, "浮點數值 =", var2)

