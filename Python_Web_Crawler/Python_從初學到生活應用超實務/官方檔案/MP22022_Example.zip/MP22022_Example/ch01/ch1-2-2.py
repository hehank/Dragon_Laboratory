grade = 76
grade_id = id(grade)
print("成績 = ", grade)
print("物件參考 = ", grade_id)
height = 175.5
height_id = id(height)
print("身高 = ", height)
print("物件參考 = ", height_id)
