name = "陳會安"
balance = 5000
print("姓名: %s 的帳戶餘額是 %d" % (name, balance))

